const addImageBtn = document.getElementById('addImageBtn');
const imageInput = document.getElementById('imageInput');
const canvas = document.getElementById('imageCanvas');
const ctx = canvas.getContext('2d');
const ocrResult = document.getElementById('ocrResult');

addImageBtn.onclick = ()=> imageInput.click();

imageInput.onchange = async (e)=>{
  const file = e.target.files[0];
  const url = URL.createObjectURL(file);
  const img = new Image();
  img.onload = async ()=>{
    canvas.width = img.width;
    canvas.height = img.height;
    ctx.drawImage(img,0,0);
    const { data:{ text }} = await Tesseract.recognize(img,'ara+eng');
    ocrResult.value = text;
  };
  img.src = url;
};
